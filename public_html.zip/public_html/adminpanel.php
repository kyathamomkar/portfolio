<?php
session_start();
 if (!(isset($_SESSION["uname"]) && !empty($_SESSION["uname"])))
 {
     
    header("Location: /./default.html");
 }
?>
<html>
<title>ADMIN PANEL</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
        <link rel="stylesheet" type="text/css" href="CSS/portfolio.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js "></script>
        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
   
     <script src="JS/update.js"></script>

<style>

.frmContact {border-top:#F0F0F0 2px solid;background:#DEE4E7;padding:10px;}
.frmContact div{margin-bottom: 15px}
.frmContact div label{margin-left: 5px}
.demoInputBox{padding:10px; border:#F0F0F0 1px solid; border-radius:4px;}
.error{background-color: #FF6600;border:#AA4502 1px solid;padding: 5px 10px;color: #FFFFFF;border-radius:4px;}
.success{background-color: #12CC1A;border:#0FA015 1px solid;padding: 5px 10px;color: #FFFFFF;border-radius:4px;}
.info{font-size:.8em;color: #FF6600;letter-spacing:2px;padding-left:5px;}
.btnAction{background-color:#187cb7;border:0;padding:10px 40px;color:#FFF;border:#F0F0F0 1px solid; border-radius:4px;}
.data {
  border-collapse: collapse;
  margin-top:10px;
}

.data, .data th, .data td {
  border: 1px solid black;
  padding:5px;
 
}

.w3-teal, .w3-hover-teal:hover {
    color: #fff!important;
    background-color: #236c97!important;
}

.imageview
{
        width: 150px;
    height: 170px;
}





table {
    table-layout:fixed;
}

table td {
    overflow:hidden;
}


</style>

<body>

<div class="w3-sidebar w3-bar-block w3-collapse w3-card w3-animate-left" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large w3-hide-large" onclick="w3_close()">Close &times;</button>

  <p  class="w3-bar-item w3-button" ><strong>EDIT</strong></p>
  <a href="#about" class="w3-bar-item w3-button">ABOUT</a>
  <a href="#education" class="w3-bar-item w3-button">EDUCATION</a>
  <a href="#skills" class="w3-bar-item w3-button">SKILLS</a>
  <a href="#experience" class="w3-bar-item w3-button">EXPERIENCE</a>
  <a href="#prices" class="w3-bar-item w3-button">PRICES</a>
  <a href="http://blog.omkarkyatham.uta.cloud/blog/wp-admin/post-new.php" class="w3-bar-item w3-button">BLOG</a>
   <a href="#projects" class="w3-bar-item w3-button">PORTFOLIO</a>
    <a id="logout" href="/./php/logout.php" class="w3-bar-item w3-button">LOGOUT</a>
  
</div>

<div class="w3-main" style="margin-left:200px">
<div class="w3-teal">
  <button class="w3-button w3-teal w3-xlarge w3-hide-large" onclick="w3_open()">&#9776;</button>
  <div class="w3-container">
    <h1>Admin Panel</h1>
   </div>
</div>

<div style="margin-left:10px" id="about">
<h4 >About Page</h4>
<div id="message"></div>

  <div class="frmContact">
     
<div id="mail-status"></div>
<div>
<label style="padding-top:20px;">Age&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
<span id="userName-info" class="info"></span>
<input type="number" name="age" id="age" class="demoInputBox">
</div>
<div>
<label>Email &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
<span id="userEmail-info" class="info"></span>
<input type="email" name="email" id="email" class="demoInputBox">
</div>
<div>
<label>Contact No&nbsp;</label> 
<span id="phone-info" class="info"></span>
<input type="number" name="phone" id="phone" class="demoInputBox">
</div>
<div>
<label>Address &nbsp;&nbsp;&nbsp;&nbsp;</label>
<span id="address-info" class="info"></span>
<input type="text" name="address" id="address" class="demoInputBox">
</div>
<div>
<label>Languages&nbsp;</label> 
<span id="languages-info" class="info"></span>
<input type="text" name="languages" id="languages" class="demoInputBox">
</div>
<div>
<label>Description</label> 
<span id="content-info" class="info"></span>
<textarea name="content" id="description" class="demoInputBox" cols="60" rows="3"></textarea>
</div>
<div>
<button name="submit" class="btnAction" onClick="sendContact();">Update</button>
</div>

<table class="data">
<tr>
<th>Id</th>
<th>Age</th>
<th>Description</th>
<th>Phone</th>
<th>Languages</th>
<th>Address</th>
<th>Email</th>
</tr>
<?php
session_start();
include "php/config.php";
$sql = "SELECT * FROM aboutuser";
$result = $con->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["userid"]. "</td><td>" . $row["age"] . "</td><td>". $row["description"]. "</td><td>" . $row["phone"] . "</td><td>". $row["languages"] ."</td><td>". $row["address"]."</td><td>".$row["email"]."</td></tr>";
}
echo "</table>";
}else
{
    echo "err";
}
$con->close();
?>
</table>

<br>
</div>
</div>
  
  
  

<div style="margin-left:10px" id="education">
<h4 >Education</h4>
<div id="message1"></div>

  <div class="frmContact">
     
<div id="education-status"></div>
 <table>
<div>
   
<tr>
<td><label style="padding-top:20px;">ID</label> </td>
<td><span id="userid-info" class="info"></span> </td>
<td><input type="number" name="userid" id="userid" class="demoInputBox" placeholder="Leave empty if new"> </td>
</tr>

</div>

<div>
<tr>
<td><label>Duration</label></td>
<td><span id="duration-info" class="info"></span></td>
<td><input type="text" name="duration" id="duration" class="demoInputBox"></td>
</tr></div>

<div>
<tr>    
<td><label>Degree</label> </td>
<td><span id="degree-info" class="info"></span></td>
<td><input type="text" name="degree" id="degree" class="demoInputBox"></td>
</tr>
</div>
<div>
    <tr>    
<td>
<label>Department</label></td>
<td>
<span id="department-info" class="info"></span></td>
<td>
<input type="text" name="department" id="department" class="demoInputBox"></td>
</tr>
</div>
<div>
    <tr>    
<td>
<label>School</label> </td>
<td>
<span id="school-info" class="info"></span></td>
<td>
<input type="text" name="school" id="school" class="demoInputBox"></td>
</tr>
</div>

<div><tr>
<td><button name="submit" class="btnAction" onClick="sendEducation(0);">Update</button>  </td><td> </td><td> 
<button name="submit" class="btnAction" onClick="sendEducation(1)">Add new</button></td>
</tr>
</div>  

<table class="data">
<tr>
<th>Userid</th>
<th>Duration</th>
<th>Degree</th>
<th>Department</th>
<th>School</th>
</tr>
<?php
session_start();
include "php/config.php";
$sql = "SELECT * FROM studies";
$result = $con->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["userid"]. "</td><td>" . $row["duration"] . "</td><td>". $row["degree"]. "</td><td>" . $row["department"] . "</td><td>". $row["school"] ."</td></tr>";
}
echo "</table>";
}else
{
    echo "err";
}
$con->close();
?>
</table>
<br>


</table>
</div>
</div> 





<div style="margin-left:10px" id="skills">
<h4 >Skills</h4>
<div id="message2"></div>

  <div class="frmContact">
     
<div id="skill-status"></div>
 <table>
<div>
   
<tr>
<td><label style="padding-top:20px;">ID</label> </td>
<td><span id="skillid-info" class="info"></span> </td>
<td><input type="number" name="skillid" id="skillid" class="demoInputBox" placeholder="Leave empty if new"> </td>
</tr>

</div>

<div>
<tr>
<td><label>Skill</label></td>
<td><span id="skill-info" class="info"></span></td>
<td><input type="text" name="skill" id="skill" class="demoInputBox"></td>
</tr></div>

<div>
<tr>    
<td><label>Percentage</label> </td>
<td><span id="percentage-info" class="info"></span></td>
<td><input type="number" name="percentage" id="percentage" class="demoInputBox"></td>
</tr>
</div>
<div><tr>
<td><button name="submit" class="btnAction" onClick="sendSkill(0);">Update Skill</button>  </td><td> </td><td> 
<button name="submit" class="btnAction" onClick="sendSkill(1);">Add new Skill</button></td>
</tr>
</div>

<table class="data">
<tr>
<th>Userid</th>
<th>Skill</th>
<th>Percentage</th>
</tr>
<?php
session_start();
include "php/config.php";
$sql = "SELECT * FROM skill";
$result = $con->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["userid"]. "</td><td>" . $row["skill"] . "</td><td>". $row["percentage"]."</td></tr>";
}
echo "</table>";
}else
{
    echo "err";
}
$con->close();
?>
</table>
<br>


</table>
</div>
</div> 

  
  
  

<div style="margin-left:10px" id="experience">
<h4 >Work Experience</h4>
<div id="message3"></div>

  <div class="frmContact">
     
<div id="experience-status"></div>
 <table>
<div>
   
<tr>
<td><label style="padding-top:20px;">ID</label> </td>
<td><span id="workid-info" class="info"></span> </td>
<td><input type="number" name="workid" id="workid" class="demoInputBox" placeholder="Leave empty if new"> </td>
</tr>

</div>

<div>
<tr>
<td><label>Duration</label></td>
<td><span id="workdurationfrom-info" class="info"></span></td>
<td><input type="date" name="workdurationfrom" id="workdurationfrom" class="demoInputBox" placeholder="mm/dd/yyyy" value=""></td><td>to</td>
<td><input type="date" name="workdurationto" id="workdurationto" class="demoInputBox" placeholder="mm/dd/yyyy" value=""></td><td><span id="workdurationto-info" class="info"></span></td>

</tr></div>

<div>
<tr>    
<td><label>Employer</label> </td>
<td><span id="employer-info" class="info"></span></td>
<td><input type="text" name="employer" id="employer" class="demoInputBox"></td>
</tr>
</div>
<div>
    <tr>    
<td>
<label>Position</label></td>
<td>
<span id="position-info" class="info"></span></td>
<td>
<input type="text" name="position" id="position" class="demoInputBox"></td>
</tr>
</div>
<div>
    <tr>    
<td>
<label>Description</label> </td>
<td>
<span id="workdescription-info" class="info"></span></td>
<td colspan="4">
<textarea name="workdescription" id="workdescription" class="demoInputBox" cols="60" rows="3"></textarea></td>
</tr>
</div>

<div><tr>
<td><button name="submit" class="btnAction" onClick="sendExperience(0);">Update</button>  </td><td> </td><td> 
<button name="submit" class="btnAction" onClick="sendExperience(1)">Add new</button></td>
</tr>
</div>  

<table class="data">
<tr>
<th>Userid</th>
<th>Duration</th>
<th>Employer</th>
<th>Position</th>
<th width="30px">Description</th>
</tr>
<?php
session_start();
include "php/config.php";
$sql = "SELECT * FROM workexperience";
$result = $con->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["companyid"]. "</td><td>" . $row["duration"] . "</td><td>". $row["employer"]. "</td><td>" . $row["position"] . "</td><td width='200'>". $row["description"] ."</td></tr>";
}
echo "</table>";
}else
{
    echo "No entries";
}
$con->close();
?>
</table>
<br>


</table>
</div>
</div> 



<div style="margin-left:10px" id="prices">
<h4 >Prices</h4>
<div id="message4"></div>

  <div class="frmContact">
     
<div id="prices-status"></div>
 <table>
<div>
   
<tr>
<td><label style="padding-top:20px;">ID</label> </td>
<td><span id="pricesid-info" class="info"></span> </td>
<td><input type="number" name="pricesid" id="pricesid" class="demoInputBox" placeholder="Leave empty if new"> </td>
</tr>

</div>

<div>
<tr>
<td><label>Pay</label></td>
<td><span id="pay-info" class="info"></span></td>
<td><input type="number" name="pay" id="pay" class="demoInputBox"></td>
</tr></div>

<div>
<tr>    
<td><label>Position</label> </td>
<td><span id="pricesposition-info" class="info"></span></td>
<td><input type="text" name="pricesposition" id="pricesposition" class="demoInputBox"></td>
</tr>
</div>

<div>
    <tr>    
<td>
<label>Roles</label> </td>
<td>
<span id="pricesrole-info" class="info"></span></td>
<td colspan="4">
<textarea name="pricesrole" id="pricesrole" class="demoInputBox" cols="40" rows="2" placeholder="Web Designing, Photo Editing, GHI"></textarea></td>
</tr>
</div>

<div><tr>
<td><button name="submit" class="btnAction" onClick="sendPrices(0);">Update</button>  </td><td> </td><td> 
<button name="submit" class="btnAction" onClick="sendPrices(1)">Add new</button></td>
</tr>
</div>  

<table class="data">
<tr>
<th>Id</th>
<th>Pay</th>
<th>Position</th>
<th>Skills</th>
</tr>
<?php
session_start();
include "php/config.php";
$sql = "SELECT * FROM prices";
$result = $con->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["userid"]. "</td><td>" . $row["pay"] . "</td><td>". $row["position"]. "</td><td>" . $row["skills"] ."</td></tr>";
}
echo "</table>";
}else
{
    echo "No Entries";
}
$con->close();
?>
</table>
<br>


</table>
</div>
</div> 

  
  
  
  
  
<div style="margin-left:10px" id="projects">
<h4 >Portfolio</h4>
<div id="message5"></div>

  <div class="frmContact">
     
<div id="projects-status"></div>
<!--
 <table>
<div>
   
<tr>
<td><label style="padding-top:20px;">ID</label> </td>
<td><span id="projectsid-info" class="info"></span> </td>
<td><input type="number" name="projectsid" id="projectsid" class="demoInputBox" placeholder="Leave empty if new"> </td>
</tr>

</div>

<div>
<tr>
<td><label>Weblink</label></td>
<td><span id="link-info" class="info"></span></td>
<td><input type="text" name="link" id="link" class="demoInputBox"></td>
</tr></div>

<div>
<tr>    
<td><label>Upload</label> </td>
<td><span id="image-info" class="info"></span></td>
<td><input type="file" name="image" id="image" class="demoInputBox"></td>
</tr>
</div>
-->

<!-- form outside table -->

<form id="my_form" method="post" enctype="multipart/form-data" action="" class="frmImageUpload"></form>

<table>
    <div>
   
<tr>
<td><label style="padding-top:20px;">ID</label> </td>
<td><span id="projectsid-info" class="info"></span> </td>
<td><input type="number" name="projectsid" id="projectsid" class="demoInputBox" placeholder="Leave empty if new" form="my_form"> </td>
</tr>

</div>

<div>
<tr>
<td><label>Weblink</label></td>
<td><span id="link-info" class="info"></span></td>
<td><input type="text" name="link" id="link" class="demoInputBox" form="my_form"></td>
</tr></div>

<div>
<tr>    
<td><label>Upload</label> </td>
<td><span id="image-info" class="info"></span></td>
<td><input type="file" name="image" id="image" class="demoInputBox" form="my_form" accept="image/x-png,image/gif,image/jpeg"></td>
</tr>
</div>

<div>
    <tr>
        <td><button class="btnAction" name="oldphoto" value="oldphoto" type="submit" form="my_form">Update</button></td>
        <td><button class="btnAction" name="newphoto" value="newphoto" type="submit" form="my_form">Add new</button></td>
         <td><button class="btnAction" name="deletephoto" value="deletephoto" type="submit" form="my_form">Delete</button></td>
    </tr>
</div>

</table>

<!--code for uploading the file -->
<?php
session_start();
include "php/config.php";

if (count($_FILES) > 0 &&  $_POST['link']!="" || $_POST['projectsid']=="") {
    $id= $_POST['projectsid'];
    $link = $_POST['link'];
    if (is_uploaded_file($_FILES['image']['tmp_name'])) {
        require_once "php/config.php";
        $imgData = addslashes(file_get_contents($_FILES['image']['tmp_name']));
        $imageProperties = getimageSize($_FILES['image']['tmp_name']);
        
        if($id!=""){
        $sql = "UPDATE portfolio_projects SET imageType='{$imageProperties['mime']}' ,image='{$imgData}' , link = '$link' WHERE id ='$id' ";
       }
       else
       {
          $sql = "INSERT INTO portfolio_projects(imageType ,image, link) VALUES('{$imageProperties['mime']}', '{$imgData}', '$link')"; 
       }
       $current_id = mysqli_query($con, $sql) or die("<b>Error:</b> Problem on Image Insert<br/>" . mysqli_error($con));
        if (isset($current_id)) {
            echo "Record succesfully executed"; 
        }
    }
}
else
{
    $id= $_POST['projectsid'];
    $sql = "DELETE from portfolio_projects WHERE id='$id'";
    if ($con->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $con->error;
}
    
}
?>



<table class="data">
<tr>
<th>Id</th>
<th>Image</th>
<th>weblink</th>

</tr>
<?php
session_start();
include "php/config.php";
$sql = "SELECT * FROM portfolio_projects";
$result = $con->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["id"]. "</td><td>";
?>
<img src="php/imageView.php?image_id=<?php echo $row["id"]; ?>" class="imageview"/>
<?
echo "</td><td>". $row["link"];



}
echo "</table>";
}else
{
    echo "No Entries";
}
$con->close();
?>
</table>
<br>


</table>
</div>
</div> 


  
  
  
  
  
  
  
  
</div>

<script>

function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>
     
</body>
</html>

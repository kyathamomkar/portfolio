<?php 
session_start();
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Portfolio Website</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
	<link href="CSS/portfolio.css" rel="stylesheet" type="text/css" />
</head>
<body class="aboutpage">
<header>
<nav>
<ul class="nav_list">
	

<?php
include "php/config.php";

// Check user login or not
if($_SESSION['uname']==""){
    echo "<li><a href='default.html'>";
    echo "LOGIN";
}
else
{
   echo "<li><a href='/php/logout.php'>";
   echo "LOGOUT";
}

?>




</a></li>
	<li><a href="contact.php">CONTACT</a></li>
	<li><a href="prices.php">PRICES</a></li>
	<li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
	<li><a href="experience.php">EXPERIENCE</a></li>
	<li><a href="portfolio.php">PORTFOLIO</a></li>
	<li><a href="skills.php">SKILLS</a></li>
	<li><a class="active_nav" href="about.php">ABOUT</a></li>
	<li><a href="default.html">HOMEPAGE</a></li>
	<li class="name_nav"><a href="default.html">OMKAR KYATHAM</a></li>
</ul>


<select onChange="window.location.href=this.value" class="select-css"> 
    <option value="" selected="selected">Select</option> 
    
     <option value="about.php">ABOUT</option> 
    <option value="skills.php">SKILLS</option> 
    <option value="portfolio.php">PORTFOLIO</option> 
    <option value="experience.php">EXPERIENCE</option> 
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option> 
    <option value="prices.php">PRICES</option> 
    <option value="contact.php">CONTACT</option>  
  </select> 
</nav>
</header>

<center>
<article class="main_article">
<section id="wrapper">
<section class="info_box">
<table class="outer_table">
	<thead>
		<tr>
			<th class="heading_about">About</th>
			<th class="heading_basicinfo">Basic Information</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="description">
			<p><br />
			<?php
			$sql = "SELECT * FROM aboutuser where userid=1";
            $result = $con->query($sql);
            $row = $result->fetch_assoc();
			echo $row["description"];
			?>
			</p>
			</td>
			<td>
			<table class="inner_table">
				<thead>
					<tr>
						<th class="fifty"></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="bold_td">AGE:</td>
						<td><?php echo $row["age"];?></td>
					</tr>
					<tr>
						<td class="bold_td">EMAIL:</td>
						<td><a href="mailto: <?php echo $row["email"]; ?>"><?php echo $row["email"];?></a></td>
					</tr>
					<tr>
						<td class="bold_td">PHONE:</td>
						<td><?php echo $row["phone"]; ?></td>
					</tr>
					<tr>
						<td class="bold_td">ADDRESS:</td>
						<td><?php echo $row["address"]; ?></td>
					</tr>
					<tr>
						<td class="bold_td">LANGUAGE:</td>
						<td><?php echo $row["languages"]; ?></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
</section>
<!-- education part --><br />
&nbsp;
<h4 class="professionalskills_heading">Education</h4>
&nbsp;

<?php 
include "php/config.php";
$sql = "SELECT * FROM studies";
$result = $con->query($sql);
$totalrows = $result->num_rows;
$counter=0;
while($row = $result->fetch_assoc())
{

?>
<table class="workexperiencetable" id="education_table">
	<tbody class="workexperiencetable_body">
		<tr class="educationtable_tr">
			<td class="workexperiencetable_td1" width="40%">
			<p class="education_year"><? echo $row["duration"] ?></p>
			&nbsp;

			<p class="education_degree"><? echo $row["degree"] ?></p>
			</td>
			<td class="workexperiencetable_td2" width="60%">
			<p class="education_course"><? echo $row["department"] ?></p>

			<p class="education_college"><? echo $row["school"] ?></p>
			</td>
		</tr>
	</tbody>
</table>
&nbsp;


<? 
    $counter++;
}

?>



</section>
</article>
</center>
</body>
</html>
<?php 
session_start();
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Portfolio Website</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
	<link href="CSS/portfolio.css" rel="stylesheet" type="text/css" />
</head>
<body>
<header>
<nav>
<ul class="nav_list">
	<li><a href=""><?php
include "php/config.php";

// Check user login or not
if($_SESSION['uname']==""){
    echo "<li><a href='default.html'>";
    echo "LOGIN";
}
else
{
   echo "<li><a href='/php/logout.php'>";
   echo "LOGOUT";
}

?></a></li>
	<li><a href="contact.php">CONTACT</a></li>
	<li><a href="prices.php">PRICES</a></li>
	<li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
	<li><a class="active_nav" href="experience.php">EXPERIENCE</a></li>
	<li><a href="portfolio.php">PORTFOLIO</a></li>
	<li><a href="skills.php">SKILLS</a></li>
	<li><a href="about.php">ABOUT</a></li>
	<li><a href="default.html">HOMEPAGE</a></li>
	<li class="name_nav"><a href="default.html">OMKAR KYATHAM</a></li>
</ul>

<select onChange="window.location.href=this.value" class="select-css"> 
    <option value="" selected="selected">Select</option> 
    
    <option value="about.php">ABOUT</option> 
    <option value="skills.php">SKILLS</option> 
    <option value="portfolio.php">PORTFOLIO</option> 
    <option value="experience.php">EXPERIENCE</option> 
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option> 
    <option value="prices.php">PRICES</option> 
    <option value="contact.php">CONTACT</option> 
  </select> 
</nav>
</header>

<center>
<article class="main_article">
<section id="wrapper">&nbsp;
<h4 class="professionalskills_heading">Work Experience</h4>
&nbsp;


<?php

include "php/config.php";
$sql = "SELECT * FROM workexperience";
$result = $con->query($sql);
$totalrows = $result->num_rows;
$counter=0;
while($row = $result->fetch_assoc())
{


?>


<table class="workexperiencetable">
	<tbody class="workexperiencetable_body">
		<tr class="workexperiencetable_tr">
			<td class="workexperiencetable_td1">
			<p class="workexperiencetable_company" style="text-align:center"><? echo $row["duration"] ?><br />
			<br />
			<? echo $row["employer"] ?></p>
			</td>
			<td class="workexperiencetable_td2">
			<p class="workexperiencetable_company_role_name"><? echo $row["position"] ?></p>

			<p class="workexperiencetable_company_role"><br />
		<? echo $row["description"] ?></p>
			</td>
		</tr>
	</tbody>
</table>
&nbsp;


<? 
    $counter++;
}

?>


</section>
</article>
</center>
</body>
</html>
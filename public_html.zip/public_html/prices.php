<?php 
session_start();
?>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Portfolio Website</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
        <link rel="stylesheet" type="text/css" href="CSS/portfolio.css">
    
    
    <style>
.flex-container {
  display: flex;
  flex-wrap: wrap;
  
  justify-content: center;
  max-width: 60%;
}

.flex-container > div {
  
  width: 250px;
  margin: 10px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
}

.prices_inner_table{
    
    text-align: center;
}
</style>
    
    
    
    
    </head>
    <body class="prices_page">
        <header>
            <nav>
                <ul class="nav_list">
                    
                    <li><a href=""><?php
include "php/config.php";

// Check user login or not
if($_SESSION['uname']==""){
    echo "<li><a href='default.html'>";
    echo "LOGIN";
}
else
{
   echo "<li><a href='/php/logout.php'>";
   echo "LOGOUT";
}

?></a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="prices.php" class="active_nav">PRICES</a></li>
                    <li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
                    <li><a href="experience.php">EXPERIENCE</a></li>
                    <li><a href="portfolio.php">PORTFOLIO</a></li>
                    <li><a href="skills.php">SKILLS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="default.html">HOMEPAGE</a></li>
                    <li class="name_nav"><a href="default.html">OMKAR KYATHAM</a></li>
              </ul>
              
              <select onChange="window.location.href=this.value" class="select-css"> 
    <option value="" selected="selected">Select</option> 
    
    <option value="about.php">ABOUT</option> 
    <option value="skills.php">SKILLS</option> 
    <option value="portfolio.php">PORTFOLIO</option> 
    <option value="experience.php">EXPERIENCE</option> 
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option> 
    <option value="prices.php">PRICES</option> 
    <option value="contact.php">CONTACT</option> 
  </select> 
            </nav>
        </header>
    <center> <br>
 <h4 class="professionalskills_heading">Prices</h4> <br><br>
<div class="flex-container">
    
    <?php 
include "php/config.php";
$sql = "SELECT * FROM prices";
$result = $con->query($sql);
$totalrows = $result->num_rows;
$counter=0;
while($row = $result->fetch_assoc())
{
 $counter++;
?>
   
    
    
    
  <div class="prices_outer_table_td"><table class="prices_inner_table" >
                             <tr height="25%"><td class="cart_td<? echo $counter; ?>"><p><i class="fa fa-shopping-cart" id="cart<? echo $counter; ?>" ></i></p></td></tr>
                                <tr><td class="workrate"><div class="bigtext"> <? echo "$".$row["pay"] ?> </div>  <? echo $row["position"] ?></td></tr>
                               <?
                               $skills_array = explode(",", $row[skills]);
                               $max = count($skills_array);
                               for($i=0;$i<$max;$i++)
                               {
                               ?>
                                <tr height="8%" id="bottomrows" class="work_tasks"><td><? echo $skills_array[$i] ?></td></tr>
                               <?
                               }
                               ?>
                                   
                                <tr height="8%" class="contact_tr" id="bottomrows"><td><a href="contact.html" class="contactus_href">Contact Us</a></td></tr>
                            </table></div>
                            
            <?
            
           if($counter==3) 
           {
               $counter=0;
           }
           
}
?>
                            
 
</center>
    </body>
</html>
<?php 
session_start();
?>

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Portfolio Website</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="CSS/portfolio.css" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
	
	<style>
.flex-container {
  display: flex;
  flex-wrap: wrap;
   box-shadow:  0px 2px 10px #999999;
  justify-content: center;
  max-width: 600px;
}

.flex-container > div  {
  
  width: 250px;
  margin: 10px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
}
</style>
</head>
<body>
<header>
<nav>
<ul class="nav_list">
	<li><a href=""><?php
include "php/config.php";

// Check user login or not
if($_SESSION['uname']==""){
    echo "<li><a href='default.html'>";
    echo "LOGIN";
}
else
{
   echo "<li><a href='/php/logout.php'>";
   echo "LOGOUT";
}

?></a></li>
	<li><a href="contact.php">CONTACT</a></li>
	<li><a href="prices.php">PRICES</a></li>
	<li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
	<li><a href="experience.php">EXPERIENCE</a></li>
	<li><a href="portfolio.php">PORTFOLIO</a></li>
	<li><a class="active_nav" href="skills.php">SKILLS</a></li>
	<li><a href="about.php">ABOUT</a></li>
	<li><a href="default.html">HOMEPAGE</a></li>
	<li class="name_nav"><a href="default.html">OMKAR KYATHAM</a></li>
</ul>

<select onChange="window.location.href=this.value" class="select-css"> 
    <option value="" selected="selected">Select</option> 
    
    <option value="about.php">ABOUT</option> 
    <option value="skills.php">SKILLS</option> 
    <option value="portfolio.php">PORTFOLIO</option> 
    <option value="experience.php">EXPERIENCE</option> 
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option> 
    <option value="prices.php">PRICES</option> 
    <option value="contact.php">CONTACT</option> 
  </select> 
</nav>
</header>

<center>
<article class="main_article">
<section id="wrapper">&nbsp;
<header>
<h2 class="professionalskills_heading">Professional Skills</h2>
</header>
&nbsp;


    
     <div class="flex-container">
    
<?php

include "php/config.php";
$sql = "SELECT * FROM skill";
$result = $con->query($sql);
$totalrows = $result->num_rows;
$counter=0;
while($row = $result->fetch_assoc())
{


?>
    

		   
			
			<div>
			
		
			<table class="subject_table">
				<tbody>
					<tr>
						<th class="subject_name"><? echo $row["skill"] ?></th>
						<th class="subject_percentage"><? echo $row["percentage"]."%" ?></th>
					</tr>
					<tr>
						<td colspan="2"><progress class="progress_bar" max="100" value="<? echo $row["percentage"] ?>"></progress></td>
					</tr>
				</tbody>
			</table>
			
			</div>
			
			<?
}
?>
		
	
		</div>

</section>
</article>
</center>
</body>
</html>
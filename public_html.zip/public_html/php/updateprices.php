<?php
session_start();
include "config.php";

$userid = mysqli_real_escape_string($con,$_POST['userid']);
$pay = mysqli_real_escape_string($con,$_POST['pay']);
$position = mysqli_real_escape_string($con,$_POST['position']);
$skills = mysqli_real_escape_string($con,$_POST['skills']);



if ( $pay!= ""&& $position != "" && $skills!= "")
{
     if($userid!="")
     {
    $sql_query = "UPDATE prices SET pay='$pay', position='$position', skills= '$skills' WHERE userid = '$userid'";
   if ($con->query($sql_query) === TRUE)
   {
    echo "Record updated successfully, Please reload";
} 
else {
    echo "Invalid userid " . $con->error;
}

}
else
{
    $sql = "INSERT INTO prices (pay,position,skills) VALUES ('$pay','$position','$skills')";
if(mysqli_query($con, $sql)){
    echo "Record inserted successfully. Please reload";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
}
else 
{
    echo "Empty data passed";
} 

 mysqli_close($con);
?>
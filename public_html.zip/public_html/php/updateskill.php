<?php
session_start();
include "config.php";

$userid = mysqli_real_escape_string($con,$_POST['userid']);
$skill = mysqli_real_escape_string($con,$_POST['skill']);
$percentage = mysqli_real_escape_string($con,$_POST['percentage']);




if ( $skill!= ""&& $percentage != "" )
{
     if($userid!="")
     {
    $sql_query = "UPDATE skill SET skill='$skill', percentage='$percentage' WHERE userid = '$userid'";
   if ($con->query($sql_query) === TRUE)
   {
     if(mysqli_affected_rows($con)==1)
     {
    echo "Record updated successfully, Please reload";
     }
     else
     {
       echo "Invalid userid ";   
     }
} 
else {
    echo "Invalid userid " . $con->error;
}

}
else
{
    $sql = "INSERT INTO skill (skill,percentage) VALUES ('$skill','$percentage')";
if(mysqli_query($con, $sql)){
    echo "Record inserted successfully. Please reload";
} else{
    echo "ERROR: Could not able to execute ";
}
}
}
else 
{
    echo "Empty data passed";
} 

 mysqli_close($con);
?>
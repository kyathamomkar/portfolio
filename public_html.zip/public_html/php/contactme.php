<?php
session_start();
include "config.php";

$name = mysqli_real_escape_string($con,$_POST['name']);
$subject = mysqli_real_escape_string($con,$_POST['subject']);
$email = mysqli_real_escape_string($con,$_POST['email']);
$message = mysqli_real_escape_string($con,$_POST['message']);



if ($name != "" && $subject  != "" && $email != "" && $message !=""){
   
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
  
   
             $sql_query = "INSERT INTO contactme(name,subject,email, message) VALUES('$name','$subject','$email' ,'$message' )";
             if(mysqli_query($con, $sql_query)){
  
            header("Location: /./contact.php");
} 
else{
    echo "ERROR: Could not able to send "; 
}
}
else echo "Invalid email format";
        }
   


?>
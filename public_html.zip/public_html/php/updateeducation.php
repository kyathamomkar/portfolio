<?php
session_start();
include "config.php";

$userid = mysqli_real_escape_string($con,$_POST['userid']);
$duration = mysqli_real_escape_string($con,$_POST['duration']);
$degree = mysqli_real_escape_string($con,$_POST['degree']);
$department = mysqli_real_escape_string($con,$_POST['department']);
$school = mysqli_real_escape_string($con,$_POST['school']);



if ( $duration!= ""&& $degree != "" && $department!= ""&&$school != "")
{
     if($userid!="")
     {
    $sql_query = "UPDATE studies SET duration='$duration', degree='$degree', department= '$department', school= '$school' WHERE userid = '$userid'";
   if ($con->query($sql_query) === TRUE)
   {
    echo "Record updated successfully, Please reload";
} 
else {
    echo "Invalid userid " . $con->error;
}

}
else
{
    $sql = "INSERT INTO studies (duration,degree,department,school) VALUES ('$duration','$degree','$department','$school')";
if(mysqli_query($con, $sql)){
    echo "Record inserted successfully. Please reload";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
}
else 
{
    echo "Empty data passed";
} 

 mysqli_close($con);
?>
<?php
session_start();
$host = "localhost"; /* Host name */
$user = "omkarkya_root"; /* User */
$password = "Omkar@123"; /* Password */
$dbname = "omkarkya_WDM_PROJECT"; /* Database name */


$con = mysqli_connect($host, $user, $password,$dbname);
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
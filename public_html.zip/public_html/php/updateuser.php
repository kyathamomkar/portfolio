<?php
session_start();
include "config.php";

$age = mysqli_real_escape_string($con,$_POST['age']);
$description = mysqli_real_escape_string($con,$_POST['description']);
$phone = mysqli_real_escape_string($con,$_POST['phone']);
$address = mysqli_real_escape_string($con,$_POST['address']);
$languages = mysqli_real_escape_string($con,$_POST['languages']);
$email = mysqli_real_escape_string($con,$_POST['email']);



if ($age != "" && $description!= ""&& $phone != "" && $address!= ""&&$languages != "" && $email!= "")
{
                 
    $sql_query = "UPDATE aboutuser SET age='$age', description='$description', email='$email', phone= '$phone', languages= '$languages', address= '$address' WHERE userid = 1";
   if ($con->query($sql_query) === TRUE)
   {
    echo "Record updated successfully";
} 
else {
    echo "Error updating record: " . $con->error;
}

}
else 
{
    echo "Empty data passed";
} 
 
 
 
?>
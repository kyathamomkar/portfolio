<?php
session_start();
include "config.php";

$uname = mysqli_real_escape_string($con,$_POST['username']);
$password = mysqli_real_escape_string($con,$_POST['password']);

if ($uname != "" && $password != ""){

    $sql_query = "select userid from users where username='".$uname."' ";
    $result = mysqli_query($con,$sql_query);
    $row = mysqli_fetch_array($result);

    $currentuser = $row['userid'];

    if($currentuser > 0){
        
        
        echo "Username already exists";
    }
        else
        {
             $sql_query = "INSERT INTO users(username,password,admin) VALUES('$uname','$password','0' )";
             if(mysqli_query($con, $sql_query)){
  
    $_SESSION["uname"] = $uname;
        echo 2;
} else{
    echo "ERROR: Could not able to register "; 
}
             
        }
    }
    else{
        echo "Please fill all fields";
    }


?>
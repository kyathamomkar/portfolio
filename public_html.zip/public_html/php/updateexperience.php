<?php
session_start();
include "config.php";

$userid = mysqli_real_escape_string($con,$_POST['userid']);
$durationfrom = mysqli_real_escape_string($con,$_POST['durationfrom']);
$durationto = mysqli_real_escape_string($con,$_POST['durationto']);
$employer = mysqli_real_escape_string($con,$_POST['employer']);
$position = mysqli_real_escape_string($con,$_POST['position']);
$description = mysqli_real_escape_string($con,$_POST['description']);

$duration = $durationfrom." to ".$durationto;


if ( $duration!= ""&& $employer != "" && $position!= ""&&$description != "")
{
     if($userid!="")
     {
    $sql_query = "UPDATE workexperience SET duration='$duration', employer='$employer', position= '$position', description= '$description' WHERE userid = '$userid'";
   if ($con->query($sql_query) === TRUE)
   {
    echo "Record updated successfully, Please reload";
} 
else {
    echo "Invalid userid " . $con->error;
}

}
else
{
    $sql = "INSERT INTO workexperience (duration,employer,position,description) VALUES ('$duration','$employer','$position','$description')";
if(mysqli_query($con, $sql)){
    echo "Record inserted successfully. Please reload";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
}
else 
{
    echo "Empty data passed";
} 

 mysqli_close($con);
?>
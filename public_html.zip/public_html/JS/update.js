
//for updating about
function sendContact() {
    var valid;	
	valid = validateContact();
	if(valid) {
		jQuery.ajax({
		url: "/./php/updateuser.php",
		data:'age='+$("#age").val()+'&description='+$("#description").val()+'&email='+$("#email").val()+'&phone='+$('#phone').val()+'&address='+$('#address').val()+'&languages='+$('#languages').val(),
		type: "POST",
		success:function(data){
		$("#mail-status").html(data);
		},
		error:function (){}
		});
	}
}



//for education

function sendEducation(x){
	var valid;	
	valid = validateEducation(x);
	if(valid) {
		jQuery.ajax({
		url: "/./php/updateeducation.php",
		data:'userid='+$("#userid").val()+'&degree='+$("#degree").val()+'&department='+$("#department").val()+'&duration='+$('#duration').val()+'&school='+$('#school').val(),
		type: "POST",
		success:function(data){
		$("#education-status").html(data);
		},
		error:function (){}
		});
	}

}

//for skills

function sendSkill(x){
	var valid;	
	valid = validateSkill(x);
	if(valid) {
		jQuery.ajax({
		url: "/./php/updateskill.php",
		data:'userid='+$("#skillid").val()+'&skill='+$("#skill").val()+'&percentage='+$("#percentage").val(),
		type: "POST",
		success:function(data){
		$("#skill-status").html(data);
		},
		error:function (){}
		});
	}

}



//for updating work experience
function sendExperience(x) {
    var valid;	
	valid = validateExperience(x);
	if(valid) {
		jQuery.ajax({
		url: "/./php/updateexperience.php",
		data:'companyid='+$("#workid").val()+'&durationfrom='+$("#workdurationfrom").val()+'&durationto='+$("#workdurationto").val()+'&employer='+$("#employer").val()+'&position='+$('#position').val()+'&description='+$('#workdescription').val(),
		type: "POST",
		success:function(data){
		$("#experience-status").html(data);
		},
		error:function (){}
		});
	}
}


//for prices

function sendPrices(x){
	var valid;	
	valid = validatePrices(x);
	if(valid) {
		jQuery.ajax({
		url: "/./php/updateprices.php",
		data:'userid='+$("#pricesid").val()+'&pay='+$("#pay").val()+'&position='+$("#pricesposition").val()+'&skills='+$('#pricesrole').val(),
		type: "POST",
		success:function(data){
		$("#prices-status").html(data);
		},
		error:function (){}
		});
	}

}



//for prices validation

function validatePrices(x) {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
if(x=="0"){
	if(!$("#pricesid").val()) {
		$("#prices-info").html("(required)");
		$("#pricesid").css('background-color','#FFFFDF');
		valid = false;
	}}

	if(!$("#pricesposition").val()) {
		$("#pricesposition-info").html("(required)");
		$("#pricesposition").css('background-color','#FFFFDF');
		valid = false;
	}
			if(!$("#pay").val()) {
		$("#pay-info").html("(required)");
		$("#pay").css('background-color','#FFFFDF');
		valid = false;
	}
		
	
	if(!$("#pricesrole").val()) {
		$("#pricesrole-info").html("(required)");
		$("#pricesrole").css('background-color','#FFFFDF');
		valid = false;
	}
	
	
	return valid;
}



function validateContact() {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
	if(!$("#age").val()||$("#age").val()<=0||$("#age").val()>99) {
		$("#userName-info").html("(required)");
		$("#age").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#email").val()) {
		$("#userEmail-info").html("(required)");
		$("#email").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#email").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
		$("#userEmail-info").html("(invalid)");
		$("#userEmail").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#phone").val()) {
		$("#phone-info").html("(required)");
		$("#phone").css('background-color','#FFFFDF');
		valid = false;
	}
		if(!$("#phone").val().match(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)) {
		$("#phone-info").html("(invalid)");
		$("#phone").css('background-color','#FFFFDF');
		valid = false;
	}
	
	if(!$("#description").val()) {
		$("#content-info").html("(required)");
		$("#description").css('background-color','#FFFFDF');
		valid = false;
	}
		if(!$("#address").val()) {
		$("#address-info").html("(required)");
		$("#address").css('background-color','#FFFFDF');
		valid = false;
	}
		if(!$("#languages").val()) {
		$("#languages-info").html("(required)");
		$("#languages").css('background-color','#FFFFDF');
		valid = false;
	}
	
	return valid;
}

//for education validation

function validateEducation(x) {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
if(x=="0"){
	if(!$("#userid").val()) {
		$("#userid-info").html("(required)");
		$("#userid").css('background-color','#FFFFDF');
		valid = false;
	}}

	if(!$("#duration").val()) {
		$("#duration-info").html("(required)");
		$("#duration").css('background-color','#FFFFDF');
		valid = false;
	}
			if(!$("#degree").val()) {
		$("#degree-info").html("(required)");
		$("#degree").css('background-color','#FFFFDF');
		valid = false;
	}
		
	
	if(!$("#department").val()) {
		$("#department-info").html("(required)");
		$("#department").css('background-color','#FFFFDF');
		valid = false;
	}
		if(!$("#school").val()) {
		$("#school-info").html("(required)");
		$("#school").css('background-color','#FFFFDF');
		valid = false;
	}
	
	return valid;
}



//for skill validation

function validateSkill(x) {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	

	if(!$("#percentage").val()) {
		$("#percentage-info").html("(required)");
		$("#percentage").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#skill").val()) {
		$("#skill-info").html("(required)");
		$("#skill").css('background-color','#FFFFDF');
		valid = false;
	}
	
	if(x=="0"){
	if(!$("#skillid").val()) {
		$("#skillid-info").html("(required)");
		$("#skillid").css('background-color','#FFFFDF');
		valid = false;
	}}
	

	return valid;
}

//for work experience validation

function validateExperience(x) {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
if(x=="0"){
	if(!$("#workid").val()) {
		$("#workid-info").html("(required)");
		$("#workid").css('background-color','#FFFFDF');
		valid = false;
	}}

	if(!$("#workdurationfrom").val()) {
		$("#workdurationfrom-info").html("(required)");
		$("#workdurationfrom").css('background-color','#FFFFDF');
		valid = false;
	}
	
	if(!$("#workdurationto").val()) {
		$("#workdurationto-info").html("(required)");
		$("#workdurationto").css('background-color','#FFFFDF');
		valid = false;
	}
	
	if(!$("#employer").val()) {
		$("#employer-info").html("(required)");
		$("#employer").css('background-color','#FFFFDF');
		valid = false;
	}
		
	
	if(!$("#position").val()) {
		$("#position-info").html("(required)");
		$("#position").css('background-color','#FFFFDF');
		valid = false;
	}
		if(!$("#workdescription").val()) {
		$("#workdescription-info").html("(required)");
		$("#workdescription").css('background-color','#FFFFDF');
		valid = false;
	}
	
	return valid;
}





